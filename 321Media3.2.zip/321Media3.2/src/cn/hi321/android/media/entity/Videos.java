//package cn.hi321.android.media.entity;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//
//public class Videos {
//
//	
//	public String getTitle() {
//		return title;
//	}
//	public void setTitle(String title) {
//		this.title = title;
//	}
//	public String getUrl() {
//		return url;
//	}
//	public void setUrl(String url) {
//		this.url = url;
//	}
//	public String getIs_play() {
//		return is_play;
//	}
//	public void setIs_play(String is_play) {
//		this.is_play = is_play;
//	}
//	public String getEpisode() {
//		return episode;
//	}
//	public void setEpisode(String episode) {
//		this.episode = episode;
//	}
//	public String getImg_url() {
//		return img_url;
//	}
//	public void setImg_url(String img_url) {
//		this.img_url = img_url;
//	}
//	public String getTvid() {
//		return tvid;
//	}
//	public void setTvid(String tvid) {
//		this.tvid = tvid;
//	}
//	public String getDownload() {
//		return download;
//	}
//	public void setDownload(String download) {
//		this.download = download;
//	}
//	public int getSec() {
//		return sec;
//	}
//	public void setSec(int sec) {
//		this.sec = sec;
//	}
//	public String getDi() {
//		return di;
//	}
//	public void setDi(String di) {
//		this.di = di;
//	}
//	private String title;
//	private String url;
//	private String is_play;
//	private String episode;
//	private String img_url;
//	private String tvid;
//	private String download;
//	private int sec;
//	private String di;
//	 
//}
