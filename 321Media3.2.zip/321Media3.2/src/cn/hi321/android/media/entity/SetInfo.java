package cn.hi321.android.media.entity;

public class SetInfo {

	public String getmItem() {
		return mItem;
	}
	public void setmItem(String mItem) {
		this.mItem = mItem;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	private String mItem;//某一集
	private String url;//某一集路径
}
