package cn.hi321.android.media.entity;

public class Orders {

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	private String name;
	private String field;
}
