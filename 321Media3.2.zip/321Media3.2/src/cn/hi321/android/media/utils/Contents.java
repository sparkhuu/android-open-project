package cn.hi321.android.media.utils;

public class Contents {
	//http://4.doukan.sinaapp.com/api/top/?pageindex=1&pagesize=20&type=tv&year=2013&area=all&cli=android&ver=1.0.6&category=all
   public static final String url = "http://4.doukan.sinaapp.com/api/top/?";
   
   public static final String SearchUrl = "http://4.doukan.sinaapp.com/api/filter/";
   
   public static final String PLAY_URL ="http://4.doukan.sinaapp.com/api/program/?";
  
   public static final String BaiDu_Url ="http://gate.baidu.com/tc?m=8&video_app=1&ajax=1&src=";
   
   
   //百度地址
   public static final String BaiDuUrl = "http://app.video.baidu.com/adapp_static/clientconfig/json/nav.json?appname=videoandroid&channel=4072a&verCode=1030502054&verName=3.5.2";
	
   public static final String BaiDuUrlRecommend = "http://app.video.baidu.com/adnativeindex/";
//   http://app.video.baidu.com/adnativeindex/?version=3.6.0
  // 视频详情界面
   public static final String XiangQingInfo = "http://app.video.baidu.com/xqinfo/";
   public static final String XiangQingSingle = "http://app.video.baidu.com/xqsingle/";
   
   public static final String APP_ID = "wxa03b529d4beae322";//wo d 
   public static final String version="3.6.0";
   public static final String cli = "android";
   public final static int CONNECTION_TIMEOUT = 30000;
   public final static int MSG_NONETWORK = -1;//没有网络
   
   public final static String PUBLISHER_ID = "56OJzTH4uNUwYhnqIG";
   
   public static final String versionBaoFeng="2.7.65";
   
}
