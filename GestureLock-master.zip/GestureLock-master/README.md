Gesture Lock
手势密码
支付宝手势密码

http://blog.csdn.net/ruils/article/details/17081207

===========

Android Gesture Lock
